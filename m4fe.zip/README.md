m4fe
====

Models for Financial Economics. European, American and Asian Option Pricing (using Binomial Trees), Interest Rate Models, Methods for Solving Partial Differential Equations.
